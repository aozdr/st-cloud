# Agent Dispatch Protocol V2

> 这是 Agent Loop 的运行时派发协议。角色定义只说明“你是谁”，TASK/Dispatch Envelope 才说明“这次具体做什么”。
> **核心原则：没有有效 Dispatch Envelope 的子 Agent 不得进入执行态，也不得把“等待任务”当成正常工作状态。**
> **V2 变更：自包含派发（消息内联全部执行输入，不携带主会话历史）+ 上下文任务隔离（scope 白/黑名单强制跨角色目录隔离）+ 任务类型分派与合并 + 子 Agent 首条消息声明 + 单层派发硬约束。**

## 1. 三层上下文

每次启动子 Agent 必须同时提供：

1. **Role Definition**：`.ai/agents/<role>.md`
   - 定义角色职责、边界、专业规则与技能配置。
2. **TASK**：`.ai/tasks/TASK-*.md`
   - 唯一编码输入。
   - 定义本次允许修改什么、验收什么。
3. **Dispatch Envelope**
   - 定义本轮为什么现在做、State/文档在哪里、验证什么、输出什么。

禁止只发送 Role Definition；也禁止只发送 Envelope 而不给角色身份。

> **协议优先级（V2）**：本协议对子 Agent 的约束**高于角色定义文件**。角色文件（`.ai/agents/*.md`）或 AGENTS.md 中任何"等待用户确认 / 等用户确认后再改码 / 向用户提问"类表述，对子 Agent 一律无效；确认权仅归主线程（Workflow Manager）。

## 2. 自包含派发（V2 新增）

**派发消息必须自包含**：消息文本本身包含子 Agent 执行所需的全部输入指引，不依赖主会话历史。

消息首段固定结构：

```text
我是 <role>（角色定义见 .ai/agents/<role>.md）。
任务类型：<backend | frontend | review | security | test | doc | ...>
本次目标：<一句话 objective>
```

消息内联字段（全部必填）：

```yaml
dispatch:
  dispatchId: "DISPATCH-<task-id>-<n>"
  taskId: "<task-id>"
  role: "<agent-role>"
  taskRefs: ["<TASK-1>", "<TASK-2>"]   # 唯一编码输入；有依赖/强关联任务合并给同一 agent 时列出全部
  stateRef: ".ai/state/<task-id>.yaml"
  objective: "本轮唯一目标"
  exitCriterion: "本轮负责的 exitCriteria"
  blockerIds: []
  artifactRefs: []
  skills:                                # V2：内联角色技能 SKILL.md 路径，强制先读再动手
    - "<SKILL.md 绝对路径>"
  scope:
    include: []                          # 允许修改 + 允许读取的目录白名单
    exclude: []                          # 跨角色目录强制黑名单（如后端 exclude st-web/**）
  acceptance: []
  validation: []
  output:
    changereportRef: ".ai/docs/<task-id>/changereport.md"
    responseSections: ["背景","输入","分析","决策","State Delta","风险","下一步","变更影响"]
  mode: "execute | review | verify | document"
  forbidSpawn: true
```

**上下文隔离规则**：
- 主 Agent 派发时不携带主会话历史（fork 最小/空为默认；极端场景由主 Agent 显式决定并说明原因）。
- 子 Agent 只依赖消息内联字段 + 按 `scope.include` 白名单读取文件。
- `scope.exclude` 之外（即白名单未覆盖）的目录**不得读取或修改**，防止后端 agent 触碰前端代码等交叉污染。

> **fork 强制约束（V2 硬规则）**：**禁止使用 `fork_turns="none"`**——实测该值不会把派发消息传给子 Agent，子 Agent 只收到系统上下文并错误进入"等待任务"态。**实测只有 `fork_turns="all"` 能确保派发消息送达**（`"1"`/`"2"` 等最小 fork 会让子 Agent 只看到最近用户对话而误把用户问题当任务，或收不到派发指令）。因此派发默认使用 `fork_turns="all"`，**并在消息首段用【唯一任务】强声明"忽略父上下文，你的执行依据只有本消息"**，配合 `scope` 白名单实现任务隔离；若后续环境验证某最小 fork 值可可靠送达，再降级使用。

## 3. 任务类型分派与合并（V2 新增）

- Workflow Manager 先按任务类型分类：前端任务只派 `frontend-engineer`，后端任务只派 `backend-engineer`，评审只派 `reviewer`/`security-reviewer`，测试只派 `tester` 等；**禁止交叉派发**（后端任务不得派给前端角色，反之亦然）。
- 有依赖/强关联的任务合并给**同一个 Agent 串行完成**（例如 TASK-01 上传链路 + TASK-02 块级同步同属后端，由同一个 backend-engineer 依次执行），不拆成多个并行 Agent。
- 仅当任务无文件重叠、无 artifact 冲突、无数据/接口契约依赖时才允许并行；并行 Agent 必须使用不同 Dispatch ID。

### 环节串行硬规则（V2）

- **每次进入新环节开启子线程前，必须先关闭上一环节的全部子线程**（`interrupt_agent` 逐个中断 + `list_agents` 确认无残留）。
- 不允许跨环节残留子线程：设计评审未收尾不得开启编码实现线程，编码未收尾不得开启 Review 线程。
- 环节结束时主线程收集全部子线程结果，对照该环节 exitCriteria 判定达标；不达标定向指导对应子线程继续执行（rework），达标后才进入下一环节。
- 子线程生命周期统一由主线程管理：创建（spawn）→ 收集（wait/结果）→ 关闭（interrupt/确认无残留）→ 判定（Evaluate）。

### Goal 完成权归主线程（V2）

- **Goal 的完成判定权只归 Workflow Manager（主线程）**：子 Agent 不定义 Goal、不判定 Goal 是否完成、不宣布迭代完成。
- 子 Agent 的产出只是"结果/Delta"；主线程收集全部子线程结果后，对照 Goal 完成标准与各环节 exitCriteria 判定达标。
- **不达标时主线程定向指导对应子线程继续执行（rework）**：给出具体缺陷与修改要求，重新派发同一 TASK，直到达标；达标后才进入下一环节。

## 4. Dispatch Envelope 必填字段

```yaml
dispatch:
  dispatchId: "DISPATCH-<task-id>-<n>"
  taskId: "<task-id>"
  role: "<agent-role>"
  taskRefs:
    - ".ai/tasks/TASK-xxx.md"        # 唯一编码输入；有依赖/强关联任务合并时列出全部
  stateRef: ".ai/state/<task-id>.yaml"
  objective: "本轮唯一目标"
  exitCriterion: "本轮负责的 exitCriteria"
  blockerIds: []
  artifactRefs: []
  skills: []
  scope:
    include: []
    exclude: []
  acceptance: []
  validation: []
  output:
    changereportRef: ".ai/docs/<task-id>/changereport.md"
    responseSections: ["背景","输入","分析","决策","State Delta","风险","下一步","变更影响"]
  mode: "execute | review | verify | document"
  forbidSpawn: true
```

## 5. 调度器职责

Workflow Manager 必须：

1. 读取 State。
2. 按任务类型分类并选择本轮主目标（可并行无依赖项）。
3. 创建/确认 TASK；有依赖任务合并给同一 Agent。
4. 生成自包含 Dispatch Envelope（含角色声明、任务类型、技能路径、scope 白/黑名单）。
5. 在派发前执行完整性检查（见 `.ai/knowledge/agent-loop-runbook.md`）。
6. 将 Role Definition + Dispatch Envelope 一起发送；不携带主会话历史。
7. 等待 Agent 返回。
8. 只消费结构化 State Delta，不把自然语言结论直接当 State。
9. Evaluate 后落盘 State。

## 6. 子 Agent 启动门禁

以下任一缺失时，禁止执行：

- taskRef / taskRefs
- stateRef
- objective
- acceptance
- validation
- scope

此时只允许返回：

`DISPATCH_INVALID: <缺失字段>`

**不得向用户提问。** 派发方是 Workflow Manager，缺字段说明派发协议失败，应让 Workflow Manager 修复派发包。

## 7. 子 Agent 执行态

收到有效 Dispatch Envelope 后，**第一条消息必须声明**：

```text
已读取 TASK + State + Scope；我是 <role>，任务类型 <type>，开始执行 <objective>。
```

然后按固定流程执行：

```text
读取 TASK
  ↓
读取 State
  ↓
读取 skills 内联的 SKILL.md 与关联文档
  ↓
确认 scope / acceptance / validation
  ↓
执行
  ↓
验证
  ↓
落盘 artifact / changereport
  ↓
返回 State Delta
```

禁止：

- 寒暄、等待用户确认、出现“请告诉我任务是什么 / 等待任务”类回复；
- **发起任何确认请求**：不得调用 request_user_input / 向用户提问 / 返回“请确认是否继续”等交互性等待；用户无法直接操作子 Agent 的确认交互，这类行为会使任务卡死；
- 重新定义 Goal；
- 自行扩大 Scope 或读取 scope 白名单之外的目录；
- 自行创建同级 Workflow Manager；
- 自行派发子 Agent；
- 用“建议下一步”代替当前任务执行。

**遇到需要决策/额外信息时的唯一出口**（按优先级）：
1. 派发消息内已定义 `acceptance`/`scope`/默认策略的，按定义自行执行，不需要确认；
2. **涉及高危操作且 TASK/design 未定版**（数据库表/字段/索引变更、接口契约变更、跨模块修改、删除/覆盖数据等），**停止执行并把确认信息返回主 Agent**：

```yaml
confirmationRequest:
  reason: "高危操作需用户确认"
  operation: "<拟执行的高危操作>"
  affected: ["<受影响文件/表/接口>"]
  risk: "<风险说明>"
  proposedPlan: "<拟执行方案>"
```

由 Workflow Manager 呈现给用户确认；用户确认后主 Agent 再重新派发/指示，子 Agent **不得自行等待或轮询用户**。
3. 需要额外专业能力的，返回 `delegationRequest`（见第 8 节），由 Workflow Manager 下一轮决定；
4. 缺少真实外部条件无法继续的，返回 `BLOCKED`（含原因），由 Workflow Manager 处理；
5. 派发包本身不完整/矛盾的，返回 `DISPATCH_INVALID: <缺失字段>`。

以上出口都是"结束本轮返回 Delta"，**绝不向用户发起确认**；需要用户决策的信息一律打包返回主 Agent。

## 8. 任务自完与单层派发（V2 强化）

- **任务自完**：拿到任务后由该 Agent 自己做完；默认只有 Workflow Manager 可以派发 Agent。
- 工程师、Reviewer、Tester 等执行 Agent **不得再创建任何子 Agent**（`forbidSpawn: true`）。
- 如果执行过程中发现需要额外专业能力：

```yaml
delegationRequest:
  reason: "需要额外专业判断"
  suggestedRole: "security-reviewer"
  objective: "..."
  blocker: true|false
```

由 Workflow Manager 在下一轮 Observe/Plan 决定是否派发，避免：

```text
WM -> Backend -> Reviewer -> Tester -> ...
```

形成失控的 Agent 套娃。

- Workflow Manager 在派发后用 `list_agents` 校验层级 = 1（WM → 专业 Agent）；出现两层以上立即 `interrupt` 越权子 Agent 并重派，记为 `DISPATCH_FAILURE`，不计入业务 blocker attempts。

## 9. 并行规则

只有满足以下条件才允许并行：

- 修改文件集合无重叠；
- 写入 artifact 无冲突；
- 目标 exitCriteria 无互相覆盖；
- 不存在数据/接口契约依赖。

并行 Agent 必须使用不同 Dispatch ID。冲突时优先串行。

## 10. Rework 规则

Review/Test/Accept 发现问题：

```text
发现问题
  ↓
创建/更新 blocker
  ↓
Plan 选择修复 Agent
  ↓
生成新的 Dispatch Envelope
  ↓
修复
  ↓
代码变更 → cascade
  ↓
重新 Review / Security / Test
```

不得复用旧 Dispatch ID，也不得把旧 Review 结果当成新代码的有效结论。

## 11. 完成判定

子 Agent 返回 `done` 不代表 exitCriteria done。

只有 Workflow Manager 在 Evaluate 阶段验证：

- artifact 真实存在；
- acceptance 全部满足；
- validation 有真实结果；
- dependsOn 已满足；
- blocker 已处理；

才可以把 exitCriteria 标记为 `done`。

## 12. 失败协议

Agent 执行失败分三类：

### BLOCKED
缺少真实外部条件，例如服务未启动、数据库不可用。

### FAILED
任务执行过但未满足验收。

### DISPATCH_INVALID
派发包本身不完整或矛盾。

其中 `DISPATCH_INVALID` 不应计入业务 blocker attempts，应直接要求 Workflow Manager 修正派发包。

# 流程 ↔ 技能映射

> 依据 `AI-Agent-Development-Workflow-Optimization.md`：将「能力型 Skill」调整为「流程型 Skill」。本项目采用 **流程职责由 Agent 承担 + 能力型技能按需引用** 策略：**不新建任何 skill 文件，保留全部现有能力型技能**。各 Agent 文档的「技能配置」章节维持现状。

## 生命周期阶段 ↔ 流程职责 ↔ 现有技能

| 阶段 | 流程职责（Agent） | 现有能力型技能 |
|------|------------------|----------------|
| 需求分析 requirement-analysis | product-manager / requirement-discovery / ui-reviewer | `prd-development` / `user-story` / `competitive-analysis` / `design-guide` |
| 架构评审 architecture-review | architect | `java-spring-boot` / `mysql` |
| 任务规划 task-planning | workflow-manager（Task 规划，见 task-template） | - |
| 实现 implementation | frontend-engineer / backend-engineer | `java-spring-boot` / `mysql` / `vercel-react-best-practices` / `vercel-composition-patterns` / `design-guide` / `frontend-design-ui-ux` |
| 代码评审 code-review | reviewer | `code-review` |
| 测试 testing | tester | `webapp-testing` / `web-design-guidelines` |
| 文档 documentation | workflow-manager / knowledge-manager | `prd-development` / `user-story` |

> 说明：`code-review` 是唯一同时具备「流程型 + 能力型」属性的技能；其余流程能力内置于各 Agent 文档（职责、输入、产出、验收标准）。技能选择由 Agent 在任务中按需引用，不改变现有加载机制，也不新增任何项目级 skill 文件。
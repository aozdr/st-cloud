# 派发消息模板 V3（自包含派发）

> **运行时强制协议**：消息必须自包含（角色声明 + 任务类型 + Dispatch Envelope + 技能路径），禁止只贴角色定义，禁止依赖主会话历史。
> **fork 强制约束**：派发时**禁止 `fork_turns="none"`**（消息无法送达子 Agent）；**默认使用 `fork_turns="all"`**（唯一被验证可送达的方式），消息首段用【唯一任务】强声明"忽略父上下文，你的执行依据只有本消息"。
> 子 Agent 收到有效派发包后立即执行并先声明身份/任务；缺字段时返回 `DISPATCH_INVALID`，不得向用户索要任务。

---

我是 **<role>**（角色定义见 `.ai/agents/<role>.md`，请先完整读取）。

任务类型：**<backend | frontend | review | security | test | doc>**

本次目标：<一句话 objective>

## 技能触发（先读 SKILL.md 再动手）

- `<skill-name>`：`<SKILL.md 绝对路径>`
- `<skill-name>`：`<SKILL.md 绝对路径>`

## Dispatch Envelope

```yaml
dispatch:
  dispatchId: "DISPATCH-<task-id>-<n>"
  taskId: "<task-id>"
  role: "<role>"
  taskRefs:
    - ".ai/tasks/TASK-<task-id>-<n>.md"   # 唯一编码输入；有依赖/强关联任务合并给同一 agent 时列出全部
  stateRef: ".ai/state/<task-id>.yaml"
  objective: "<本轮唯一目标>"
  exitCriterion: "<本轮负责的 exitCriteria>"
  blockerIds: []
  artifactRefs:
    - "<相关文档>"
  skills:
    - "<SKILL.md 绝对路径>"
  scope:
    include:
      - "<允许修改/读取的目录白名单，如 st-core/**>"
    exclude:
      - "<跨角色目录强制黑名单，如 st-web/**、st-desktop/**>"
  acceptance:
    - "<验收标准>"
  validation:
    - "<真实验证命令>"
  output:
    changereportRef: ".ai/docs/<task-id>/changereport.md"
    responseSections:
      - "背景"
      - "输入"
      - "分析"
      - "决策"
      - "State Delta"
      - "风险"
      - "下一步"
      - "变更影响"
  mode: "execute"
  forbidSpawn: true
```

## 执行协议

1. 第一条消息声明：`已读取 TASK + State + Scope；我是 <role>，任务类型 <type>，开始执行 <objective>`。
2. 读取 `taskRefs`，它们是唯一编码输入。
3. 读取 `stateRef`，只消费与本轮相关的状态。
4. 读取 `skills` 内联的 SKILL.md 与 `artifactRefs` 中必要文档。
5. 严格限制在 `scope.include` 白名单内读取/修改；**不得读取 scope 白名单之外的目录**，不得触碰 `scope.exclude`。
6. 完成 `acceptance`。
7. 执行 `validation`，记录真实结果。
8. 按需落盘 `changereportRef`。
9. 返回完整 State Delta。

**禁止：**
- 等待用户继续分配任务；
- **发起确认请求**：不得调用 request_user_input / 向用户提问 / 返回“请确认是否继续”等交互性等待；用户无法操作子 Agent 的确认交互；
- 自行扩大任务范围或读取白名单外目录；
- 生成/派发任何子 Agent（`forbidSpawn: true`，任务自完；需要额外专业能力时返回 `delegationRequest`）；
- 把“建议下一步”当成当前任务；
- 未验证就声称完成。

**需要决策/额外信息时的唯一出口**（绝不向用户确认）：
- 派发消息已定义验收/范围/默认策略 → 按定义自行执行；
- 涉及**高危操作**（数据库表/字段/索引变更、接口契约变更、跨模块修改、删除/覆盖数据）且 TASK/design 未定版 → **停止执行**，返回 `confirmationRequest`（reason/operation/affected/risk/proposedPlan），由 Workflow Manager 呈现给用户确认后再指示；
- 需要额外专业能力 → 返回 `delegationRequest`；
- 缺少真实外部条件 → 返回 `BLOCKED`（含原因）；
- 派发包不完整 → 返回 `DISPATCH_INVALID: <缺失字段>`。

## 示例（后端自包含派发）

我是 **backend-engineer**（角色定义见 `.ai/agents/backend-engineer.md`，请先完整读取）。

任务类型：**backend**

本次目标：修复上传链路与块级同步的 Code Review blocker。

## 技能触发（先读 SKILL.md 再动手）

- `java-spring-boot`：`C:/Users/Administrator/.agents/skills/java-spring-boot/SKILL.md`
- `mysql`：`C:/Users/Administrator/.agents/skills/mysql/SKILL.md`

## Dispatch Envelope

```yaml
dispatch:
  dispatchId: "DISPATCH-20260813-code-review-rework-BE"
  taskId: "20260813-code-review-rework"
  role: "backend-engineer"
  taskRefs:
    - ".ai/tasks/TASK-20260813-code-review-rework-01.md"
    - ".ai/tasks/TASK-20260813-code-review-rework-02.md"
  stateRef: ".ai/state/20260813-code-review-rework.yaml"
  objective: "修复后端 9 项 blocker（C1/M1~M8）"
  exitCriterion: "IMPLEMENTED（后端部分）"
  blockerIds: ["C1","M1","M2","M3","M4","M5","M6","M7","M8"]
  artifactRefs:
    - ".ai/docs/20260813-code-review-rework/design.md"
  skills:
    - "C:/Users/Administrator/.agents/skills/java-spring-boot/SKILL.md"
    - "C:/Users/Administrator/.agents/skills/mysql/SKILL.md"
  scope:
    include:
      - "st-core/**"
      - "st-sync/**"
      - "docker/mysql/init/**"
    exclude:
      - "st-web/**"
      - "st-desktop/**"
      - ".ai/**"
  acceptance:
    - "acquire 复活 deleted 行，重传不 NPE"
    - "block-upload 仅信任会话字段"
  validation:
    - "mvn -pl st-core -am test"
    - "mvn -pl st-sync -am test"
  output:
    changereportRef: ".ai/docs/20260813-code-review-rework/changereport.md"
    responseSections: ["背景","输入","分析","决策","State Delta","风险","下一步","变更影响"]
  mode: "execute"
  forbidSpawn: true
```

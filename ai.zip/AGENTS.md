# 星云盘 AI 研发总规则 V4（Agent Loop）

这是云盘项目 AI 研发总规则。

所有用户请求首先经 Workflow Manager（Loop 编排器）分类并初始化 Loop State，随后由编排器循环驱动各 Agent 直至退出标准全部满足。详见 `.ai/agents/workflow-manager.md` 与 `.ai/knowledge/loop-state-model.md`。

## 子 Agent 身份识别（最高优先级，先于一切其它规则）

**当你是被主 Agent（Workflow Manager）派发的子 Agent 时**：

- 你的唯一任务是**执行派发消息（Dispatch Envelope）中指定的 TASK**，不是"接收用户请求"，不是"分类需求"，不是"定义 Goal"，不是"等待任务"。
- 上文的"所有用户请求首先经 Workflow Manager 分类"、Goal 与 Plan 强制门禁、"修改前等待用户确认"等条款**只适用于主线程（Workflow Manager）与用户之间的交互，不适用于子 Agent 执行态**。
- 派发消息 = 角色声明 + 任务类型 + Dispatch Envelope（taskRefs/stateRef/scope/acceptance/validation）。**消息即任务**：禁止忽略消息去"读上下文猜任务"，禁止回复"请告诉我做什么 / 等待任务"，禁止把 AGENTS.md 的面向主线程规则当作自己的待办。
- 你的四个合法出口：① 按 Dispatch 已定验收/scope 执行完毕返回 State Delta；② 高危操作未定版 → 返回 `confirmationRequest` 给主 Agent；③ 需额外专业能力 → 返回 `delegationRequest`；④ 派发包不完整 → 返回 `DISPATCH_INVALID: <缺失字段>`。**任何出口都不得向用户发起确认，不得创建子 Agent。**
- 收到派发消息后的第一条回复必须声明：`已读取 TASK + State + Scope；我是 <role>（子 Agent），任务类型 <type>，开始执行 <objective>`。

## 环节串行：子线程生命周期（主线程硬规则）

- **每次进入新的环节（REQ_ANALYSIS / IMPACT_ANALYSIS / EXP_DESIGN / TECH_DESIGN / TESTCASES / IMPLEMENTED / CODE_REVIEW / SECURITY_REVIEW / EXP_ACCEPT / TEST_PASS / QUALITY_GATE / KNOWLEDGE）开启子线程前，主线程必须先关闭上一环节的全部子线程**（`interrupt_agent` 逐个中断，`list_agents` 确认无残留）。
- 同一环节内可并行派发多个无依赖子线程；**不允许跨环节残留子线程**（例如设计评审未收尾就开启编码实现线程）。
- 环节结束时，主线程收集全部子线程结果、对照该环节 exitCriteria 判定达标；不达标时定向指导对应子线程继续执行，达标后才进入下一环节。
- 子线程生命周期由主线程统一管理：创建（spawn）→ 收集（wait/结果）→ 关闭（interrupt/确认无残留）→ 判定（Evaluate）。

------------------------------------------------------------------------

# Goal 与 Plan 强制门禁

## Goal 定义

所有任务必须先定义 Goal。

Goal 必须包含：

-   客观目标
-   影响范围
-   完成标准

未定义 Goal 不得开始工作。

## Goal 完成权归主线程（子 Agent 不判定 Goal）

- **Goal 的完成判定权只归主线程（Workflow Manager）**。子 Agent 不定义 Goal、不判定 Goal 是否完成、不宣布"迭代完成"。
- 子 Agent 的产出只是"结果/Delta"；主线程收集全部子线程结果后，对照 Goal 的完成标准与各环节 exitCriteria 判定是否达标。
- **不达标时，主线程定向指导对应的子线程继续执行（rework）**——给出具体缺陷与修改要求，重新派发同一 TASK，直到该环节达标；达标后才进入下一环节。
- 子 Agent 之间不互评、不互派、不互相"验收"；验收与达标判定全部由主线程统一执行。

## Plan 触发条件

满足任一条件必须生成 Plan，并等待用户确认：

-   修改超过 3 个文件
-   新增页面、模块、组件
-   数据库表、字段、索引变化
-   文件上传、下载、分享、同步、权限、配额等核心流程变化
-   跨模块功能修改

## Plan 必须包含

1.  修改范围
2.  实现步骤
3.  风险点
4.  验证方式

------------------------------------------------------------------------

# Workflow Manager

所有需求首先进入 Workflow Manager。

职责：

-   创建 Goal 并初始化 Loop State
-   判断任务规模，加载对应退出标准集
-   每轮执行 Observe -> Plan -> Act -> Evaluate 循环
-   动态调度 Agent（可并行派发）
-   检查门禁依赖与收敛条件，驱动 Loop 到退出标准全部满足

任务分类：

## 小型任务

例如：

-   单文件 Bug 修复
-   配置调整
-   样式微调

允许直接执行。

## 中型任务

例如：

-   单模块功能增强
-   新增接口

退出标准（Loop 收敛条件）：

设计 -> 实现 -> Code Review -> 安全审查（条件） -> 测试 -> 知识库回顾

## 大型任务

例如：

-   跨模块功能
-   数据模型变化
-   核心业务流程变化

完整 Loop 退出标准（12 项）：

需求分析 -> 影响分析 -> 体验评审 -> 技术设计 -> 测试用例 -> 实现 -> Code Review
-> Security Review -> 体验验收 -> 测试执行 -> Quality Gate -> 知识库更新

> 非线性顺序执行：编排器每轮按 State 重新规划派发，rework 即重新规划而非退格。详见 `.ai/knowledge/loop-state-model.md`。

------------------------------------------------------------------------

# AI 团队成员

  Agent                   职责
  ----------------------- --------------------
  Workflow Manager        统一入口和流程调度
  Project Manager         项目推进和状态管理
  Product Manager         需求分析和产品设计（与UI协作产出文档）
  Requirement Discovery   模糊需求澄清与结构化（可选上游，竞品调研为可选输入）
  Impact Analyzer         影响范围分析
  Architect               架构设计和技术决策
  Experience Reviewer     UI/UX体验评审
  UI Designer & Reviewer   UI设计与评审（需求阶段与PM协作产出设计文档）
  Frontend Engineer       前端设计与开发
  Backend Engineer        后端设计与开发
  Tester                  测试设计与执行
  Code Reviewer           代码质量审查
  Security Reviewer       安全审查
  Quality Gate            最终交付门禁
  Knowledge Manager       知识库维护

------------------------------------------------------------------------

# Agent 行为准则

所有 Agent 在执行任务时须遵守以下通用行为准则：

-   解释复杂内容时善用可视化，降低理解成本
-   保持简洁直接，明确区分事实与猜测，不臆断结论
-   基于可靠来源进行研究与判断，不编造信息
-   不偏离用户目标与约束，聚焦当前任务边界
-   不随意提问，仅关键决策点才向用户确认
-   合理使用子 Agent，避免无意义并行（详见“子任务协作”）
-   修改代码保持克制，不做无关重构，变更最小化
-   必须验证真实结果，而非“看起来完成”
-   保护已有代码与数据，避免破坏性操作
-   汇报关键结果，不刷无意义进度
-   最终输出的结果必须使用中文

------------------------------------------------------------------------

# 代码修改强制约束（7 条）

所有代码修改必须遵守以下强制约束：

1.  有对应 Task 文件：中型及以上任务修改代码前必须存在对应 `.ai/tasks/TASK-xxx.md`；小型直接执行任务除外，但对话中必须给出「目标 / 修改范围 / 禁止修改范围」摘要
2.  明确修改范围：严格遵循 Task 文件的「修改范围」，禁止越界修改未授权文件
3.  修改前输出方案：修改前先输出实施计划/方案；涉及数据库、接口契约、跨模块变更时须等待用户确认后再改码；**派发到子 Agent 的任务必须在 TASK/design 中定版，子 Agent 禁止直接向用户发起确认（确认权仅归主线程）；子 Agent 遇到未定版的高危操作（数据库/接口/跨模块/删除覆盖等）时停止执行，将确认信息以 `confirmationRequest` 返回主 Agent，由主 Agent 向用户确认后再指示**
4.  修改后执行测试：改动完成后运行对应构建/测试，验证真实结果，不得"看起来完成"
5.  禁止无需求重构：不做与任务无关的重构，变更最小化
6.  数据库变化必须说明迁移方案：涉及表/字段/索引/数据变更必须给出迁移脚本或迁移方案
7.  API 变化必须说明兼容策略：涉及接口契约变化必须说明向后兼容策略或升级方案

# 数据库版本管理

## 版本表

数据库含 `schema_version` 表，记录每次迭代的版本号与执行的 SQL 文件清单：

| 字段 | 说明 |
|------|------|
| `version_tag` | 版本号，格式 `YYYYMMDD.N`（N=当日序号） |
| `iteration_name` | 迭代名称/主题 |
| `applied_sql_files` | 本次执行的 SQL 文件清单，逗号分隔（相对 `docker/mysql/init/`） |
| `applied_at` | 执行时间 |
| `applied_by` | 执行人/Agent 标识 |
| `notes` | 备注 |

## 每次迭代强制流程

涉及数据库变更的迭代，必须按以下顺序执行：

1.  **新建迁移脚本**：在 `docker/mysql/init/` 下新增编号递增的 `.sql` 文件
2.  **同步 H2 schema**：在 `st-core/src/test/resources/schema.sql` 中补齐对应表/列
3.  **运行 H2 测试**：`mvn test` 全绿（含 `SchemaConsistencyTest` 三层校验）
4.  **对比正式数据库**：H2 测试通过后，运行 `.ai/scripts/compare-schema.ps1` 对比 MySQL 实际 schema，确认无列差异
5.  **执行迁移到 MySQL**：将新增 `.sql` 文件执行到运行中的 MySQL（Docker 容器已运行时不会自动执行 init 脚本）
6.  **更新版本记录**：向 `schema_version` 表 INSERT 本次迭代记录，包含版本号、迭代名称、执行的 SQL 文件清单
7.  **再次对比确认**：重新运行 `compare-schema.ps1` 确认 PASS（退出码 0）

> **禁止跳过**：H2 测试通过 ≠ MySQL 正常。`schema.sql` 是手动维护的，与生产 MySQL 可能漂移。
> `compare-schema.ps1` 是强制门禁，未通过不得标记 `TEST_PASS` done。

## 版本号规则

-   格式：`YYYYMMDD.N`，N 为当日序号（从 1 开始）
-   每次迭代递增，不可复用已存在的 `version_tag`
-   基线版本 `20260811.1` 记录历史全量迁移（02~25 号脚本）

# 开发流程门禁（Agent Loop 版）

门禁不再是线性 15 步顺序，而是 **Loop 退出标准 + 门禁依赖**。编排器每轮在 Evaluate 段检查。

## Loop 循环（每轮强制四段）

1.  Observe 读 State：未满足标准 / open blockers / 历史
2.  Plan 基于当前 State 推导最高价值动作，选 Agent（可并行）
3.  Act 派发 Agent(带 State) -> 返回 State Delta
4.  Evaluate 应用 Delta -> 检查门禁依赖 -> 死循环检测 -> 收敛判断

## 退出标准（按规模）

-   小型：实现 -> 验证 -> 知识库检查
-   中型：设计 -> 实现 -> Code Review -> 安全审查（条件项，涉及权限/文件操作时启用） -> 测试 -> 知识库
-   大型（12 项）：需求分析 -> 影响分析 -> 体验评审 -> 技术设计 -> 测试用例 -> 实现 -> Code Review -> Security Review -> 体验验收 -> 测试执行 -> Quality Gate -> 知识库

> 完整定义见 `.ai/knowledge/loop-state-model.md`。

## 门禁依赖（不可降级，等价于旧版禁止项）

-   未完成需求分析不得标设计类标准 done
-   体验评审须先于技术设计（TECH_DESIGN 依赖 EXP_DESIGN）
-   未完成技术设计不得进入开发（IMPLEMENTED 依赖 TECH_DESIGN）
-   大型任务未编写测试用例不得开发（IMPLEMENTED 依赖 TESTCASES）
-   未通过 Code Review 与 Security Review 不得测试（TEST_PASS 依赖 CODE_REVIEW, SECURITY_REVIEW）
-   未通过 Quality Gate 不得 `status: done`

## 死循环与升级

-   同一 blocker 连续 3 轮未解除 -> 升级人工，暂停 Loop
-   超轮次上限（large=40 / medium=15 / small=5）-> 升级人工

## rework 规则

Review/测试/验收发现问题不退格，编排器重新 Plan 派发对应 Agent 修复后复检对应标准。
-   代码变更触发级联回退：IMPLEMENTED 重开时其全部下游标准自动回退 pending，需重新满足（详见 .ai/knowledge/loop-state-model.md 代码变更失效规则）

------------------------------------------------------------------------

# Agent 输出规范

所有 Agent 输出必须包含：

## 背景

说明任务原因。

## 输入

列出使用的信息（含读取的 Loop State 关键字段）。

## 分析

说明判断过程。

## 决策

说明最终方案。

## State Delta

说明对 Loop State 的变更：新增/更新的 artifacts、新增/解除的 blockers、勾选的 exitCriteria。编排器据此在 Evaluate 段更新 State。

## 风险

说明潜在问题。

## 下一步

说明建议的下一个动作/Agent（供编排器 Plan 参考，非强制）。

## 变更影响

说明本次变更对其他模块/Agent/exitCriteria 的影响。

------------------------------------------------------------------------

# 云盘专项规则

重点关注：

-   文件权限安全
-   分享访问控制
-   上传下载稳定性
-   数据一致性
-   用户操作效率
-   大文件处理体验

核心逻辑必须添加中文注释。

包括：

-   权限校验
-   状态流转
-   配额计算
-   去重逻辑
-   文件处理规则

------------------------------------------------------------------------

# 子任务协作

开发、测试、Review 必须合理拆分子任务。

原则：

-   无依赖任务并行
-   有依赖任务明确顺序
-   完成后统一汇总

## 前后端并行执行协议（IMPLEMENTED 阶段）

-   **前置**：TECH_DESIGN 与 TESTCASES 均 done 后，Workflow Manager 将实现拆分为前端 TASK 与后端 TASK，两文件集零重叠；接口契约以 `design.md` 的 API 章节定版，前端可先用 mock 并行开发，接口就绪后联调。
-   **任务类型分派**：按任务类型派发——前端任务只派 frontend-engineer、后端任务只派 backend-engineer、评审只派 reviewer/security-reviewer、测试只派 tester，禁止交叉派发（后端任务不得派给前端角色，反之亦然）；有依赖/强关联的多个 TASK 合并给同一个 Agent 串行完成，不拆成多个并行 Agent。
-   **派发**：创建子任务线程时，按 `.ai/templates/dispatch-template.md`（V3 自包含派发）生成消息 = 角色声明 + 任务类型 + Dispatch Envelope + 技能 SKILL.md 路径，禁止只贴角色定义；消息必须包含：角色 / TASK 文件路径（唯一编码输入，可多个 taskRefs）/ State 路径 / 关联文档（design、testcases、uispec）/ 技能路径 / 修改与禁止范围（scope 白/黑名单，跨角色目录强制隔离，如后端 exclude `st-web/**`）/ 验收标准 / 验证命令 / 输出要求；派发时不携带主会话历史，上下文由消息内联字段 + scope 白名单文件读取构成。
-   **fork 强制约束**：创建子任务线程时**禁止 `fork_turns="none"`**（实测派发消息无法送达子 Agent，导致子 Agent 进入"等待任务"态）；默认使用 `fork_turns="all"`（唯一被验证可送达），消息首段【唯一任务】强声明"忽略父上下文，你的执行依据只有本消息"。
-   **子任务行为**：子 agent 收到派遣消息后立即执行，首条消息声明“我是 <role>，任务类型 <type>，开始执行 <objective>”，禁止寒暄、禁止等待确认；**禁止向用户发起任何确认请求（不得调用 request_user_input / 提问 / “请确认是否继续”），用户无法操作子 Agent 的确认交互，此类行为会使任务卡死**；编码输入只接受 TASK 文件；**任务自完，禁止再派发任何子 Agent（forbidSpawn）**，需要额外专业能力时返回 `delegationRequest`，缺少外部条件时返回 `BLOCKED`，派发包不完整时返回 `DISPATCH_INVALID`，均不向用户确认；完成后追加 `.ai/docs/<task-id>/changereport.md` 对应章节并回复结果摘要。
-   **合并与验收**：Workflow Manager 等待全部子任务返回，合并 changereport.md，执行集成验证（`mvn test` + `npm run build` / `tsc`），全部通过才标记 IMPLEMENTED done 并进入 Review。
-   **rework**：Review/测试/验收打回时，通过 follow-up 消息定向派发对应子任务修复；代码变更触发级联回退（见 `.ai/knowledge/loop-state-model.md`）。

------------------------------------------------------------------------

# 文档产出与留存

中大型任务必须产出文档并保存到项目中，供用户审阅与后续回顾。

## 强制规则

-   产品经理输出**需求文档**，开发工程师输出**程序设计文档**
-   文档必须落盘到项目目录 `.ai/docs/`，按迭代建子文件夹归档（见 `.ai/knowledge/document-management.md`），不得仅停留在对话中
-   产出后必须在对话中告知用户文档路径，确保用户可打开查看
-   文档长期留存，作为项目资产供回顾、复盘、知识库同步，不得删除
-   命名规范、存放与可见性细则见 `.ai/knowledge/document-management.md`
-   各类文档的内容结构遵循 `docs/newList/` 下对应输出标准，基于 `.ai/templates/` 模板填写
-   所有产出文档统一使用 **UTF-8（无 BOM）** 编码；含中文的 `.ps1` 脚本使用 UTF-8 with BOM 以兼容 Windows PowerShell

## 文档类型

-   需求文档（PM 产出，归属 REQ_ANALYSIS）-- 背景、用户故事、功能范围、验收标准
-   UI 设计文档（UI Designer 产出，归属 REQ_ANALYSIS/EXP_DESIGN）-- 页面定位、信息层级、交互、视觉规范
-   需求发现报告（需求发现 Agent 产出，可选上游）-- 需求澄清、功能拆解、业务规则、需求输出
-   架构设计评审（Architect 产出，归属 TECH_DESIGN 前置）-- 整体架构、技术选型、性能/安全/扩展性、风险
-   程序设计文档（前后端工程师产出，归属 TECH_DESIGN）-- 架构、接口、数据设计、修改范围
-   测试用例（Tester 产出，归属 TESTCASES）-- 测试范围、用例、覆盖要求、接口测试
-   Code Review 记录（Reviewer 产出，归属 CODE_REVIEW）-- 结构/安全/性能检查、问题清单、结论
-   Task 文件（Workflow Manager 产出，归属 IMPLEMENTED 前置）-- 目标、修改范围、禁止修改范围、验收标准、测试要求
-   Change Report（前后端工程师产出，归属 IMPLEMENTED）-- 修改文件清单、与验收标准对照、测试结果、风险
-   ADR 架构决策记录（Architect/工程师产出，知识沉淀）-- 背景、决策、放弃的方案、理由、后续限制

> 各文档内容结构遵循 `docs/newList/` 下对应输出标准，模板见 `.ai/templates/`，对应关系见 `.ai/knowledge/document-management.md`。

> 未产出对应文档不得标记该阶段 exitCriteria done；文档对用户不可见视为未完成。

------------------------------------------------------------------------

# 知识库维护

每次迭代完成后：

Knowledge Manager 检查：

-   架构文档
-   数据模型
-   API文档
-   业务规则
-   UI设计规范
-   安全规则
-   ADR 架构决策记录

保持知识库与代码一致。


## Agent Loop V5 运行时硬规则

本项目采用 `.ai/knowledge/agent-dispatch-protocol.md`（V2，自包含派发 + 上下文任务隔离）作为子 Agent 运行时协议。

### 调度权唯一化

- Workflow Manager 是唯一默认的 Agent 调度者。
- 其他 Agent 不得自行创建同级子 Agent。
- 需要额外专业能力时，只能返回 `delegationRequest`，由 Workflow Manager 下一轮决定。

### Role / Task / Dispatch 三分离

- Role Definition = 角色身份与专业边界
- TASK = 本次唯一编码输入
- Dispatch Envelope = 本轮目标、State、范围、验收、验证和输出契约

**禁止只发送 Role Definition 启动子 Agent。**

### 空派发禁止

创建子 Agent 前必须确认：

`taskRef + stateRef + objective + exitCriterion + scope + acceptance + validation`

缺任何一项属于 `DISPATCH_INVALID`，不是业务 blocker，不得让子 Agent 向用户索要任务。

### 子 Agent 不等待

收到有效 Dispatch 后必须立即执行。禁止“请告诉我需要处理什么”“等待任务”“等待用户确认”等空闲状态。

### done 不是完成

子 Agent 的“完成”只代表返回 Delta；Workflow Manager 必须在 Evaluate 阶段验证 artifact、验收、验证命令、依赖和 blocker 后才能勾选 exitCriteria。

### Dispatch 失败恢复

如果子 Agent 返回 `DISPATCH_INVALID` 或“未收到具体任务”，Workflow Manager 必须检查并重新生成 Dispatch，不得直接把它当成用户输入缺失。

### Agent 套娃限制

默认最多一层：

`Workflow Manager -> 专业 Agent`

专业 Agent 不得继续调度。二级需求通过 `delegationRequest` 返回给 Workflow Manager。

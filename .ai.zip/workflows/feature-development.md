# Feature Development Workflow V2

## 流程

用户需求
↓
Workflow Manager
↓
任务分类
↓
Impact Analyzer（复杂需求）
↓
Requirement Discovery
↓
Product Manager
↓
需求评审
↓
Experience Reviewer
↓
Architect / Technical Design
↓
设计评审
↓
测试设计
↓
Frontend / Backend Implementation
↓
Code Reviewer
↓
Experience Reviewer UI验收
↓
Tester
↓
Quality Gate
↓
Knowledge Manager
↓
完成

## 质量要求

任何阶段发现阻塞问题必须返回上一阶段修正。
